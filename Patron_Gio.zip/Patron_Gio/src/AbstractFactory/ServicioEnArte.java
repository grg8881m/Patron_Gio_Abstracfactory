
package AbstractFactory;

public interface ServicioEnArte {
    public void asignarTrabajo();
    public void indicarFechaEntrega();
    public void informarSobrePago();
}
