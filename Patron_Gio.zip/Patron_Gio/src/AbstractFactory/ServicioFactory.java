
package AbstractFactory;

public interface ServicioFactory {
    public ServicioEnArte crearServicio();
}
